create definer = xxx@`%` trigger increment_comment_count
    after insert
    on comment
    for each row
BEGIN
    UPDATE video_data
    SET comment_count = comment_count  + 1
    WHERE video_id = NEW.video_id;
END;

