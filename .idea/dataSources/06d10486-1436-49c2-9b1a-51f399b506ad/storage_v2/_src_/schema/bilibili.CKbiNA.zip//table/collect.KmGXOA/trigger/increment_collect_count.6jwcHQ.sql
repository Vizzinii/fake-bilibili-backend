create definer = xxx@`%` trigger increment_collect_count
    after insert
    on collect
    for each row
BEGIN
    UPDATE video_data
    SET collect_count  = collect_count  + 1
    WHERE video_id = NEW.video_id;
END;

