create definer = xxx@`%` trigger increment_play_count
    after insert
    on play
    for each row
BEGIN
    UPDATE video_data
    SET play_count = play_count  + 1
    WHERE video_id = NEW.video_id;
END;

